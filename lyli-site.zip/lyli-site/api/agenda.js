"use strict";
/*
  API única do site (agendamento + painel admin).
  Banco: Upstash Redis (Vercel Storage). As variáveis são criadas AUTOMÁTICAS
  quando você clica em "Connect" no Vercel. Sem banco conectado, o site continua
  funcionando em modo de teste (memória temporária) e o painel avisa.
*/
const crypto = require("crypto");

const TIMES = ["09:30", "14:00", "18:00"];
const MAX_DAYS = 45;
const TZ = "America/Sao_Paulo";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "nail.designer";

const norm = (s) => String(s || "").trim().toLowerCase();
const sha = (s) => crypto.createHash("sha256").update(s).digest();
const SECRET = sha("lyli-admin-v1|" + norm(ADMIN_PASSWORD) + "|" + (process.env.TOKEN_SALT || ""));

/* ---------- Banco de dados ---------- */
const REDIS_URL = (process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL || "").replace(/\/$/, "");
const REDIS_TOKEN = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN || "";
const PERSISTENT = !!(REDIS_URL && REDIS_TOKEN);

async function rc(args) {
  const r = await fetch(REDIS_URL, {
    method: "POST",
    headers: { Authorization: "Bearer " + REDIS_TOKEN, "Content-Type": "application/json" },
    body: JSON.stringify(args),
  });
  const j = await r.json();
  if (!r.ok || j.error) throw new Error(j.error || "redis " + r.status);
  return j.result;
}

const mem = { h: new Map(), s: new Map(), c: new Map() };
const db = PERSISTENT
  ? {
      hsetnx: async (k, f, v) => Number(await rc(["HSETNX", k, f, v])) === 1,
      hdel: (k, f) => rc(["HDEL", k, f]),
      hgetall: async (k) => {
        const r = await rc(["HGETALL", k]);
        const o = {};
        if (Array.isArray(r)) for (let i = 0; i < r.length; i += 2) o[r[i]] = r[i + 1];
        else if (r && typeof r === "object") Object.assign(o, r);
        return o;
      },
      sadd: (k, m) => rc(["SADD", k, m]),
      smembers: async (k) => (await rc(["SMEMBERS", k])) || [],
      incr: async (k, ttl) => {
        const n = Number(await rc(["INCR", k]));
        if (n === 1) await rc(["EXPIRE", k, String(ttl)]);
        return n;
      },
    }
  : {
      hsetnx: async (k, f, v) => {
        if (!mem.h.has(k)) mem.h.set(k, new Map());
        const m = mem.h.get(k);
        if (m.has(f)) return false;
        m.set(f, v);
        return true;
      },
      hdel: async (k, f) => { const m = mem.h.get(k); if (m) m.delete(f); },
      hgetall: async (k) => Object.fromEntries(mem.h.get(k) || []),
      sadd: async (k, m) => { if (!mem.s.has(k)) mem.s.set(k, new Set()); mem.s.get(k).add(m); },
      smembers: async (k) => [...(mem.s.get(k) || [])],
      incr: async (k, ttl) => {
        const now = Date.now();
        let c = mem.c.get(k);
        if (!c || c.exp < now) c = { n: 0, exp: now + ttl * 1000 };
        c.n++;
        mem.c.set(k, c);
        return c.n;
      },
    };

/* ---------- Datas (sempre no horário de Brasília) ---------- */
function nowSP() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", hourCycle: "h23",
  }).formatToParts(new Date());
  const o = {};
  parts.forEach((p) => (o[p.type] = p.value));
  return { date: `${o.year}-${o.month}-${o.day}`, min: Number(o.hour) * 60 + Number(o.minute) };
}
function addDays(s, n) {
  const d = new Date(s + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
function validDate(s) {
  if (typeof s !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(s + "T12:00:00Z");
  return !isNaN(d) && d.toISOString().slice(0, 10) === s;
}

/* ---------- Utilidades ---------- */
function cleanName(v) {
  return String(v || "").replace(/[\u0000-\u001f\u007f<>]/g, " ").replace(/\s+/g, " ").trim().slice(0, 60);
}
function cleanPhone(v) {
  return String(v || "").replace(/\D/g, "").slice(0, 15);
}
function ipOf(req) {
  return String(req.headers["x-forwarded-for"] || req.headers["x-real-ip"] || "x").split(",")[0].trim();
}
function makeToken() {
  const exp = String(Date.now() + 12 * 3600 * 1000);
  const sig = crypto.createHmac("sha256", SECRET).update(exp).digest("hex");
  return exp + "." + sig;
}
function checkToken(t) {
  try {
    const [exp, sig] = String(t || "").split(".");
    if (!exp || !sig || Number(exp) < Date.now()) return false;
    const good = crypto.createHmac("sha256", SECRET).update(exp).digest("hex");
    const a = Buffer.from(sig), b = Buffer.from(good);
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch (e) { return false; }
}

/* ---------- Handler ---------- */
module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  const send = (code, obj) => res.status(code).json(obj);
  const isAdmin = () => checkToken((req.headers.authorization || "").replace(/^Bearer\s+/i, ""));

  try {
    const q = req.query || {};

    /* ===== GET ===== */
    if (req.method === "GET") {
      if (q.admin === "list") {
        if (!isAdmin()) return send(401, { error: "Sessão expirada. Entre novamente." });
        const hoje = nowSP().date;
        const days = (await db.smembers("ag:days")).filter((d) => validDate(d) && d >= hoje).sort();
        const rows = await Promise.all(days.map(async (d) => [d, await db.hgetall("ag:" + d)]));
        const items = [];
        for (const [date, f] of rows) {
          for (const time of TIMES) {
            if (!f[time]) continue;
            let v = {};
            try { v = JSON.parse(f[time]); } catch (e) {}
            items.push({ date, time, type: v.t === "x" ? "block" : "booking", name: v.n || "", phone: v.p || "" });
          }
        }
        return send(200, { hoje, persistent: PERSISTENT, times: TIMES, items });
      }
      const date = String(q.date || "");
      if (!validDate(date)) return send(400, { error: "Data inválida." });
      const f = await db.hgetall("ag:" + date);
      return send(200, { taken: TIMES.filter((t) => f[t]) });
    }

    if (req.method !== "POST") return send(405, { error: "Método não permitido." });

    let b = req.body;
    if (typeof b === "string") { try { b = JSON.parse(b); } catch (e) { b = {}; } }
    if (!b || typeof b !== "object") b = {};
    const action = String(b.action || "book");

    /* ===== Login ===== */
    if (action === "login") {
      const n = await db.incr("rl:login:" + ipOf(req), 900);
      if (n > 8) return send(429, { error: "Muitas tentativas. Aguarde 15 minutos." });
      const a = sha(norm(b.password)), c = sha(norm(ADMIN_PASSWORD));
      if (!crypto.timingSafeEqual(a, c)) return send(401, { error: "Senha incorreta." });
      return send(200, { token: makeToken() });
    }

    /* ===== Ações do painel ===== */
    if (action !== "book") {
      if (!isAdmin()) return send(401, { error: "Sessão expirada. Entre novamente." });
      const date = String(b.date || "");
      if (!validDate(date)) return send(400, { error: "Data inválida." });
      const time = b.time ? String(b.time) : "";
      if (time && !TIMES.includes(time)) return send(400, { error: "Horário inválido." });
      const key = "ag:" + date;

      if (action === "cancel") {
        if (!time) return send(400, { error: "Horário obrigatório." });
        await db.hdel(key, time);
        return send(200, { ok: true });
      }
      if (action === "unblockday") {
        const f = await db.hgetall(key);
        for (const t of TIMES) {
          try { if (f[t] && JSON.parse(f[t]).t === "x") await db.hdel(key, t); } catch (e) {}
        }
        return send(200, { ok: true });
      }
      if (action === "block") {
        await db.sadd("ag:days", date);
        for (const t of time ? [time] : TIMES) await db.hsetnx(key, t, JSON.stringify({ t: "x" }));
        return send(200, { ok: true });
      }
      if (action === "add") {
        const name = cleanName(b.name);
        if (!time || name.length < 2) return send(400, { error: "Informe horário e nome." });
        await db.sadd("ag:days", date);
        const ok = await db.hsetnx(key, time, JSON.stringify({ t: "b", n: name, p: cleanPhone(b.phone), at: new Date().toISOString() }));
        return ok ? send(200, { ok: true }) : send(409, { error: "Esse horário já está ocupado." });
      }
      return send(400, { error: "Ação inválida." });
    }

    /* ===== Reserva de cliente ===== */
    if (b.site) return send(200, { ok: true }); // isca anti-robô
    const n = await db.incr("rl:book:" + ipOf(req), 3600);
    if (n > 10) return send(429, { error: "Muitas tentativas. Tente novamente mais tarde." });

    const date = String(b.date || ""), time = String(b.time || "");
    const name = cleanName(b.name), phone = cleanPhone(b.phone);
    if (!validDate(date)) return send(400, { error: "Data inválida." });
    if (!TIMES.includes(time)) return send(400, { error: "Horário inválido." });
    if (name.length < 2) return send(400, { error: "Digite seu nome." });
    if (phone && (phone.length < 10 || phone.length > 13)) return send(400, { error: "WhatsApp inválido. Use DDD + número." });

    const now = nowSP();
    if (date < now.date || date > addDays(now.date, MAX_DAYS)) return send(400, { error: "Data indisponível. Escolha outro dia." });
    const [h, m] = time.split(":").map(Number);
    if (date === now.date && h * 60 + m <= now.min) return send(400, { error: "Esse horário já passou. Escolha outro." });

    await db.sadd("ag:days", date);
    const ok = await db.hsetnx("ag:" + date, time, JSON.stringify({ t: "b", n: name, p: phone, at: new Date().toISOString() }));
    if (!ok) return send(409, { error: "Esse horário acabou de ser reservado." });
    return send(200, { ok: true });
  } catch (e) {
    console.error(e);
    return send(503, { error: "Serviço temporariamente indisponível. Tente novamente em instantes." });
  }
};
